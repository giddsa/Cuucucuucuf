import React, { useState, useCallback, useMemo } from 'react';
import { Header } from './components/Header';
import { UploadPanel } from './components/UploadPanel';
import { SettingsPanel } from './components/SettingsPanel';
import { ResultsPanel } from './components/ResultsPanel';
import { Footer } from './components/Footer';
import { ChatPanel } from './components/ChatPanel';
import { LoadingSpinner, ErrorIcon, AnalyzerIcon, ChatBubbleIcon } from './components/Icons';
import { AnalysisResult, Kline, Language, UploadedImage, TradingType } from './types';
import { translations } from './constants';
import { processAnalysis } from './services/analysisService';
import { generateAnalysisExplanation, analyzeChartImage } from './services/geminiService';

type ActiveTab = 'analyzer' | 'chat';

const App: React.FC = () => {
    const [language, setLanguage] = useState<Language>('en');
    const [activeTab, setActiveTab] = useState<ActiveTab>('analyzer');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
    const [leverage, setLeverage] = useState<number>(10);
    const [tradingType, setTradingType] = useState<TradingType>('futures');
    const [klineData, setKlineData] = useState<Kline[] | null>(null);
    const [uploadedImage, setUploadedImage] = useState<UploadedImage | null>(null);

    const t = useMemo(() => translations[language], [language]);

    const handleAnalyze = useCallback(async () => {
        if (!klineData && !uploadedImage) {
            setError(t.errorNoData);
            return;
        }

        setIsLoading(true);
        setError(null);
        setAnalysisResult(null);

        const finalLeverage = tradingType === 'spot' ? 1 : leverage;

        try {
            let finalResult: AnalysisResult;

            if (uploadedImage) {
                finalResult = await analyzeChartImage(uploadedImage, finalLeverage, language);
            } else if (klineData) {
                const numericalAnalysis = processAnalysis(klineData, finalLeverage);
                const geminiExplanation = await generateAnalysisExplanation(numericalAnalysis, language);
                finalResult = {
                    ...numericalAnalysis,
                    ...geminiExplanation
                };
            } else {
                throw new Error("No data available to analyze.");
            }
            
            setAnalysisResult(finalResult);

        } catch (err) {
            console.error(err);
            const errorMessage = (err instanceof Error) ? err.message : t.errorAnalysisFailed;
            if (errorMessage.includes('API key not valid')) {
                 setError(t.errorApiKey);
            } else if (uploadedImage) {
                setError(t.errorVisionAnalysisFailed);
            }
            else {
                 setError(errorMessage);
            }
        } finally {
            setIsLoading(false);
        }
    }, [klineData, uploadedImage, leverage, tradingType, language, t]);

    const handleDataLoaded = useCallback((data: Kline[] | UploadedImage) => {
        setError(null);
        setAnalysisResult(null);
        if (Array.isArray(data)) {
            setKlineData(data);
            setUploadedImage(null);
        } else {
            setUploadedImage(data);
            setKlineData(null);
        }
    }, []);

    const handleClear = useCallback(() => {
        setKlineData(null);
        setUploadedImage(null);
        setAnalysisResult(null);
        setError(null);
    }, []);

    const renderAnalyzer = () => (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-1 flex flex-col gap-6">
                <UploadPanel onDataLoaded={handleDataLoaded} onClear={handleClear} t={t} />
                <SettingsPanel 
                    leverage={leverage} 
                    setLeverage={setLeverage}
                    tradingType={tradingType}
                    setTradingType={setTradingType} 
                    t={t} 
                />
                <button
                    onClick={handleAnalyze}
                    disabled={isLoading || (!klineData && !uploadedImage)}
                    className="w-full bg-brand-primary hover:bg-brand-secondary text-white font-bold py-3 px-4 rounded-lg transition duration-300 disabled:bg-gray-500 disabled:cursor-not-allowed flex items-center justify-center"
                >
                    {isLoading && <LoadingSpinner />}
                    {isLoading ? t.analyzing : t.analyzeNow}
                </button>
                {error && (
                     <div className="bg-red-900/50 border border-brand-danger text-red-300 px-4 py-3 rounded-lg relative flex items-start space-x-2 rtl:space-x-reverse" role="alert">
                        <ErrorIcon className="h-5 w-5 mt-0.5"/>
                        <span>{error}</span>
                    </div>
                )}
            </div>
            <div className="lg:col-span-2">
                <ResultsPanel result={analysisResult} klineData={klineData} isLoading={isLoading} t={t} />
            </div>
        </div>
    );

    return (
        <div dir={language === 'ar' ? 'rtl' : 'ltr'} className={`${language === 'ar' ? 'font-arabic' : 'font-sans'} min-h-screen bg-brand-bg text-brand-text-primary flex flex-col`}>
            <Header language={language} setLanguage={setLanguage} t={t} />
            <main className="flex-grow container mx-auto p-4 md:p-6 lg:p-8">
                <div className="mb-6">
                    <div className="border-b border-brand-border">
                        <nav className="-mb-px flex space-x-6 rtl:space-x-reverse" aria-label="Tabs">
                            <button
                                onClick={() => setActiveTab('analyzer')}
                                className={`${
                                    activeTab === 'analyzer'
                                        ? 'border-brand-primary text-brand-primary'
                                        : 'border-transparent text-brand-text-secondary hover:text-brand-text-primary hover:border-gray-500'
                                } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center gap-2`}
                            >
                                <AnalyzerIcon className="w-5 h-5" />
                                {t.analyzerTab}
                            </button>
                            <button
                                onClick={() => setActiveTab('chat')}
                                className={`${
                                    activeTab === 'chat'
                                        ? 'border-brand-primary text-brand-primary'
                                        : 'border-transparent text-brand-text-secondary hover:text-brand-text-primary hover:border-gray-500'
                                } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center gap-2`}
                            >
                                <ChatBubbleIcon className="w-5 h-5"/>
                                {t.chatTab}
                            </button>
                        </nav>
                    </div>
                </div>

                {activeTab === 'analyzer' ? renderAnalyzer() : <ChatPanel t={t} language={language} />}

            </main>
            <Footer t={t} />
        </div>
    );
};

export default App;