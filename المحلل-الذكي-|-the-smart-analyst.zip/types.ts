export type Language = 'en' | 'ar';
export type TradingType = 'futures' | 'spot';

export interface Kline {
    timestamp: number;
    open: number;
    high: number;
    low: number;
    close: number;
    volume: number;
}

export interface UploadedImage {
    data: string; // base64 encoded data
    mimeType: string;
}

export interface ChatMessage {
    role: 'user' | 'model';
    parts: { text: string }[];
}


export interface Indicators {
    rsi: number;
    macd: {
        macd: number;
        signal: number;
        hist: number;
    };
    atr: number;
    ema: {
        '9': number;
        '21': number;
        '50': number;
    };
    bollinger: {
        upper: number;
        middle: number;
        lower: number;
    };
}

export type Position = 'Long' | 'Short' | 'Stay Out';

export interface NumericalAnalysisResult {
    symbol: string;
    timeframe: string;
    possible_position: Position;
    trend_direction: 'Uptrend' | 'Downtrend' | 'Sideways';
    possible_entry: number;
    take_profit: number;
    stop_loss: number;
    rr_ratio: number;
    confidence: number;
    indicators: Indicators;
}

export interface GeminiAnalysisResult {
    analysis_summary: string;
    analysis_explanation: string;
}


export type AnalysisResult = NumericalAnalysisResult & GeminiAnalysisResult;


export interface Translation {
    // Header
    headerTitle: string;
    
    // Tabs
    analyzerTab: string;
    chatTab: string;

    // Upload Panel
    uploadTitle: string;
    uploadImage: string;
    uploadData: string;
    or: string;
    uploadInstructions: string;
    uploading: string;
    removeImage: string;
    
    // Settings Panel
    settingsTitle: string;
    tradingType: string;
    futures: string;
    spot: string;
    leverage: string;
    
    // Main Controls
    analyzeNow: string;
    analyzing: string;

    // Results Panel
    analysisResults: string;
    waitingForAnalysis: string;
    chart: string;
    recommendation: string;
    position: string;
    entryPrice: string;
    takeProfit: string;
    stopLoss: string;
    riskRewardRatio: string;
    confidence: string;
    summary: string;
    fullAnalysis: string;
    saveAnalysis: string;
    disclaimer: string;
    
    // Positions
    long: string;
    short: string;
    stayOut: string;

    // Chat Panel
    chatWithSato: string;
    satoWelcome: string;
    chatPlaceholder: string;
    send: string;

    // Errors & Notes
    errorNoData: string;
    errorAnalysisFailed: string;
    errorApiKey: string;
    errorVisionAnalysisFailed: string;
    errorChatFailed: string;

    // Footer
    instagramLink: string;
}