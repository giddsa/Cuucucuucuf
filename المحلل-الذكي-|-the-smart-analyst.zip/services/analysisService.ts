
import { Kline, NumericalAnalysisResult } from '../types';

const calculateEMA = (prices: number[], period: number): number => {
    if (prices.length < period) return 0;
    const k = 2 / (period + 1);
    let ema = prices.slice(0, period).reduce((a, b) => a + b, 0) / period; // Initial SMA
    for (let i = period; i < prices.length; i++) {
        ema = (prices[i] * k) + (ema * (1 - k));
    }
    return ema;
};

const calculateRSI = (prices: number[], period = 14): number => {
    if (prices.length <= period) return 50;
    const changes = prices.slice(1).map((price, i) => price - prices[i]);
    const recentChanges = changes.slice(-period);

    const gains = recentChanges.filter(c => c > 0).reduce((sum, c) => sum + c, 0);
    const losses = recentChanges.filter(c => c < 0).reduce((sum, c) => sum + Math.abs(c), 0);

    const avgGain = gains / period;
    const avgLoss = losses / period;

    if (avgLoss === 0) return 100;
    const rs = avgGain / avgLoss;
    return 100 - (100 / (1 + rs));
};

const calculateATR = (klines: Kline[], period = 14): number => {
    if (klines.length <= period) return 0;
    const trueRanges: number[] = [];
    for (let i = Math.max(1, klines.length - period - 1); i < klines.length; i++) {
        const k = klines[i];
        const prevClose = klines[i - 1].close;
        const tr = Math.max(k.high - k.low, Math.abs(k.high - prevClose), Math.abs(k.low - prevClose));
        trueRanges.push(tr);
    }
    if (trueRanges.length === 0) return 0;
    return trueRanges.reduce((a, b) => a + b, 0) / trueRanges.length; // Simple ATR
};


export const processAnalysis = (klineData: Kline[], leverage: number): NumericalAnalysisResult => {
    if (klineData.length < 50) {
        throw new Error("Not enough data for analysis. At least 50 data points are required.");
    }
    const lastKline = klineData[klineData.length - 1];
    const currentPrice = lastKline.close;
    const closePrices = klineData.map(k => k.close);

    const ema9 = calculateEMA(closePrices, 9);
    const ema21 = calculateEMA(closePrices, 21);
    const ema50 = calculateEMA(closePrices, 50);
    const rsi = calculateRSI(closePrices, 14);
    const atr = calculateATR(klineData, 14);

    let possible_position: 'Long' | 'Short' | 'Stay Out' = 'Stay Out';
    let trend_direction: 'Uptrend' | 'Downtrend' | 'Sideways' = 'Sideways';
    let confidence = 0.5; 

    // Rule-Based Logic
    if (ema9 > ema21 && ema21 > ema50 && currentPrice > ema50) {
        trend_direction = 'Uptrend';
        confidence += 0.2;
        if (rsi > 50 && rsi < 70) {
            possible_position = 'Long';
            confidence += 0.2;
        }
    } else if (ema9 < ema21 && ema21 < ema50 && currentPrice < ema50) {
        trend_direction = 'Downtrend';
        confidence += 0.2;
        if (rsi < 50 && rsi > 30) {
            possible_position = 'Short';
            confidence += 0.2;
        }
    }

    const rr_ratio = 2.0;
    let possible_entry = currentPrice;
    let take_profit = currentPrice;
    let stop_loss = currentPrice;
    
    if (possible_position === 'Long') {
        stop_loss = currentPrice - (atr * 1.5);
        take_profit = currentPrice + (currentPrice - stop_loss) * rr_ratio;
    } else if (possible_position === 'Short') {
        stop_loss = currentPrice + (atr * 1.5);
        take_profit = currentPrice - (stop_loss - currentPrice) * rr_ratio;
    } else {
        stop_loss = currentPrice - atr * 2;
        take_profit = currentPrice + atr * 2;
    }
    
    confidence = Math.max(0.3, confidence - (leverage / 250));

    return {
        symbol: "BTCUSDT",
        timeframe: "1h",
        possible_position,
        trend_direction,
        possible_entry,
        take_profit,
        stop_loss,
        rr_ratio,
        confidence: Math.min(0.95, confidence),
        indicators: {
            rsi,
            macd: { macd: 0, signal: 0, hist: 0 }, // Not implemented, returning zero
            atr,
            ema: { '9': ema9, '21': ema21, '50': ema50 },
            bollinger: { upper: 0, middle: 0, lower: 0 }, // Not implemented, returning zero
        },
    };
};
